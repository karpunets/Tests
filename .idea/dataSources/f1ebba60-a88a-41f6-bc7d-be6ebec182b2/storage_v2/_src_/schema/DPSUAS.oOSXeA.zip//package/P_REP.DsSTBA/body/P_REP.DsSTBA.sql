create PACKAGE BODY P_Rep AS
  FUNCTION put_ (iID       Rep.ID%TYPE,
                 iNAME     Rep.NAME%TYPE,
                 iTITLE    Rep.TITLE%TYPE,
                 iTABLE_1  Rep.TABLE_1%TYPE,
                 iJOIN_CL  Rep.JOIN_CL%TYPE,
                 iTABLE_N  Rep.TABLE_N%TYPE,
                 iON_CL    Rep.ON_CL%TYPE,
                 iFIELDS   Rep.FIELDS%TYPE,
                 iWHERE_CL Rep.WHERE_CL%TYPE,
                 iORDER_CL Rep.ORDER_CL%TYPE,
                 iGROUP_CL Rep.GROUP_CL%TYPE,
                 iREPTYPE  Rep.REPTYPE%TYPE,
                 iPosition Rep.Position%TYPE,
                 iTEMPLATE_TYPE Rep.TEMPLATE_TYPE%TYPE)
    RETURN CLOB IS
    vID Rep.ID%TYPE;
      e_update exception;
    v_err_code number;
    v_err_mes varchar2(100);
    vREPTYPE    Rep.REPTYPE%TYPE;
    Begin
      if iID is null then
        insert into Rep ( NAME,  TITLE,  TABLE_1,  JOIN_CL,  TABLE_N,  ON_CL,  FIELDS,  WHERE_CL,  ORDER_CL,  GROUP_CL,  REPTYPE,  Position,  TEMPLATE_TYPE)
        values (iNAME, iTITLE, iTABLE_1, iJOIN_CL, iTABLE_N, iON_CL, iFIELDS, iWHERE_CL, iORDER_CL, iGROUP_CL, iREPTYPE, iPosition, iTEMPLATE_TYPE)
        returning ID into vID;
      else
        select  REPTYPE, ID
        into vREPTYPE, vID
        from Rep
        Where id = iID;
        if vREPTYPE not in ('SYSTEM') then
          update Rep
          set NAME     = iNAME,
            TITLE    = iTITLE,
            TABLE_1  = iTABLE_1,
            JOIN_CL  = iJOIN_CL,
            TABLE_N  = iTABLE_N,
            ON_CL    = iON_CL,
            FIELDS   = iFIELDS,
            WHERE_CL = iWHERE_CL,
            ORDER_CL = iORDER_CL,
            GROUP_CL = iGROUP_CL,
            REPTYPE  = iREPTYPE,
            Position = iPosition,
            TEMPLATE_TYPE = iTEMPLATE_TYPE
          Where id = iID;
        else
          v_err_code := -20001;
          v_err_mes :=  'REPTYPE field cannot be SYSTEM!';
          raise e_update;
        end if;
      end if;
      commit;
      return Select_('<ROW><WHERE> Where ID = '||vID||' </WHERE></ROW>', null, null);
      EXCEPTION
      WHEN e_update THEN
      return f_result_xml(null, v_err_code, v_err_mes);
      WHEN OTHERS THEN
      rollback;
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;
  FUNCTION Select_ (iInput CLOB, iSkipRows number, iMaxRows number)
    RETURN CLOB IS
    v_result CLOB;
    v_Where  varchar(32000);
    v_Order  varchar(32000);
    v_ctx    dbms_xmlgen.ctxHandle;
    Begin
      select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
        extractValue(value(t),'ROW/ORDER[position()=1]')
      into v_Where,
        v_Order
      from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;

      v_ctx := dbms_xmlgen.newContext('select * from REP '||v_Where||' '||v_Order );
      if iMaxRows  is not null then DBMS_XMLGEN.SETMAXROWS ( v_ctx, iMaxRows);  end if;
      if iSkipRows is not null then DBMS_XMLGEN.SETSKIPROWS (v_ctx, iSkipRows); end if;
      dbms_xmlgen.SETNULLHANDLING(v_ctx,2);
      v_result := dbms_xmlgen.getxml(v_ctx);
      dbms_xmlgen.closeContext(v_ctx);
      return v_result;
      EXCEPTION
      WHEN OTHERS THEN
      dbms_xmlgen.closeContext(v_ctx);
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;

  FUNCTION Count_  (iInput CLOB)
    RETURN CLOB IS
    v_result CLOB;
    v_Where  varchar(32000);
    v_Order  varchar(32000);
    v_ctx    dbms_xmlgen.ctxHandle;
    Begin
      select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
        extractValue(value(t),'ROW/ORDER[position()=1]')
      into v_Where,
        v_Order
      from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;

      v_ctx := dbms_xmlgen.newContext('select count(*) COUNT from REP '||v_Where/*||' '||v_Order*/ );
      dbms_xmlgen.SETNULLHANDLING(v_ctx,2);
      v_result := dbms_xmlgen.getxml(v_ctx);
      dbms_xmlgen.closeContext(v_ctx);
      return v_result;
      EXCEPTION
      WHEN OTHERS THEN
      dbms_xmlgen.closeContext(v_ctx);
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;

  FUNCTION Delete_ (iID Rep.ID%TYPE)
    RETURN CLOB IS
      e_delete exception;
    v_err_code number;
    v_err_mes varchar2(100);
    vREPTYPE    Rep.REPTYPE%TYPE;
    Begin
      select  REPTYPE
      into vREPTYPE
      from Rep
      Where id = iID;
      if vREPTYPE not in ('SYSTEM') then
        delete
        from Rep
        where id = iID;
        commit;
      else
        v_err_code := -20001;
        v_err_mes :=  'REPTYPE field cannot be SYSTEM!';
        raise e_delete;
      end if;
      return f_result_xml(iID, null, null);
      EXCEPTION
      WHEN e_delete THEN
      return f_result_xml(null, v_err_code, v_err_mes);
      WHEN OTHERS THEN
      rollback;
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;

  FUNCTION Execute_ (iNAME Rep.Name%TYPE, iInput CLOB, iSkipRows number, iMaxRows number)
    RETURN CLOB is
    v_result CLOB;
    v_from   varchar(32000) := ' from ';
    v_Where  varchar(32000);
    v_Order  varchar(32000);
    v_ctx    dbms_xmlgen.ctxHandle;
    v_fields varchar(32000);
    v_group_by varchar(32000);
    --v_tmp  varchar(4000);
    --v_group_by_F boolean;
    Begin
      select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
        extractValue(value(t),'ROW/ORDER[position()=1]')
      into v_Where,
        v_Order
      from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;

      if v_Where is null then  v_Where := ' Where 1 = 1 '; end if;

      FOR rec IN (SELECT TABLE_1, JOIN_CL, TABLE_N, ON_CL
                  from REP
                  where Name = iNAME
                  order by Position)
      LOOP

        v_from := v_from||' '||rec.TABLE_1;
        if rec.TABLE_N is not null then
          v_from := v_from||' '||rec.JOIN_CL||' '||rec.TABLE_N||' ON ( '||rec.ON_CL||' ) ';
        end if;
      end LOOP;

      --         FOR rec IN (SELECT Ltrim(regexp_substr(Regexp_Replace(FIELDS||',','( as )|('||chr(13)||')|('||chr(10)||')',' ',1,0,'i'), '[^,]+', 1, level)) Field
      --                       from REP
      --                      where Name = iNAME
      --                        and Position = 1
      --                    connect by level <= regexp_count(FIELDS, ',')+1
      --                        and prior id = id
      --                        and prior dbms_random.value is not null    ) 
      --         LOOP
      --         v_fields := v_fields ||' '||rec.Field||' , ';
      --         v_tmp := rtrim(substr(rec.Field,1,instr(rec.Field,'(')-1));
      --          if v_tmp is not null then
      --           v_tmp := substr(v_tmp, instr(v_tmp, ' ', -1)+1);
      --           if lower(v_tmp) in ('sum','min','max','count') then
      --            v_group_by_F := true;
      --           end if;
      --          else
      --           v_group_by := v_group_by|| replace(rtrim(substr(lower(rec.Field),1,instr(rec.Field,'"')-1)),'disitnct','') ||' , ';
      --          end if;
      --         end LOOP;
      --         
      --         v_fields := rtrim(v_fields, ', ');
      --         v_group_by  := rtrim(v_group_by, ', ');
      --         if v_fields is null then v_fields := '*'; end if;
      --
      --         if v_group_by_F and v_group_by is not null then v_group_by := ' group by '||v_group_by; 
      --                                                    else v_group_by := null;
      --         end if;
      FOR rec IN (SELECT FIELDS, WHERE_CL, ORDER_CL, GROUP_CL
                  from REP
                  where Name = iNAME
                        and Position = 1)
      loop
        if rec.FIELDS is not null   then v_fields := rec.FIELDS; else v_fields := ' * '; end if;
        --if rec.WHERE_CL is not null then v_Where    := v_Where ||' and '||rec.WHERE_CL; end if; /*10.12.2018 You do not see into DB (Kolya)*/
        if rec.ORDER_CL is not null then v_Order    := ' order by '|| rec.ORDER_CL;     end if;
        if rec.GROUP_CL is not null then v_group_by := ' group by '||rec.GROUP_CL;      end if;
      end loop;

      v_ctx := dbms_xmlgen.newContext('select '||v_fields||' '||v_from||' '||v_Where||' '||v_group_by||' '||v_Order );
      if iMaxRows  is not null then DBMS_XMLGEN.SETMAXROWS ( v_ctx, iMaxRows);  end if;
      if iSkipRows is not null then DBMS_XMLGEN.SETSKIPROWS (v_ctx, iSkipRows); end if;
      dbms_xmlgen.SETNULLHANDLING(v_ctx,2);
      v_result := dbms_xmlgen.getxml(v_ctx);
      dbms_xmlgen.closeContext(v_ctx);

      return v_result;
      EXCEPTION
      WHEN OTHERS THEN
      dbms_xmlgen.closeContext(v_ctx);
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;

  FUNCTION Count_Ex  (iNAME Rep.Name%TYPE, iInput CLOB)
    RETURN CLOB IS
    v_result CLOB;
    v_exec   CLOB;
    v_Count  number;
    v_ctx    dbms_xmlgen.ctxHandle;

    Begin
      v_exec := Execute_(iNAME, iInput, null, null);
      if v_exec is null then v_Count:= 0;
      else
        select count(*)
        into v_Count
        from table(XMLSequence(XMLType(v_exec).extract('//ROW'))) t;
      end if;

      v_ctx := dbms_xmlgen.newContext('select '||v_Count||' COUNT from dual');
      dbms_xmlgen.SETNULLHANDLING(v_ctx,2);
      v_result := dbms_xmlgen.getxml(v_ctx);
      dbms_xmlgen.closeContext(v_ctx);

      return v_result;
      EXCEPTION
      WHEN OTHERS THEN
      dbms_xmlgen.closeContext(v_ctx);
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;
END P_Rep;
/

