create PACKAGE p_FIELDS_STRUCTURE AS 
   FUNCTION add_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                  iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                  iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                  iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                  iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                  iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                  iFIELDTYPE FIELDS_STRUCTURE.FIELDTYPE%TYPE,
                  iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                  iFROMDICTIONARYPARRENT FIELDS_STRUCTURE.FROMDICTIONARYPARRENT%TYPE,
                  iTITLE FIELDS_STRUCTURE.TITLE%TYPE,
                  iFIELDSIZE FIELDS_STRUCTURE.FIELDSIZE%TYPE,
                  iINPUTFULLSIZE FIELDS_STRUCTURE.INPUTFULLSIZE%TYPE,
                  iFIELDORDER FIELDS_STRUCTURE.FIELDORDER%TYPE,
                  iSHOWTYPE FIELDS_STRUCTURE.SHOWTYPE%TYPE) 
      RETURN CLOB; 
   FUNCTION UPDATE_ (iID FIELDS_STRUCTURE.ID%TYPE,
                     --iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                     iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                     iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                     iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                     iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                     iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                     iFIELDTYPE FIELDS_STRUCTURE.FIELDTYPE%TYPE,
                     iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                     iFROMDICTIONARYPARRENT FIELDS_STRUCTURE.FROMDICTIONARYPARRENT%TYPE,
                     iTITLE FIELDS_STRUCTURE.TITLE%TYPE,
                     iFIELDSIZE FIELDS_STRUCTURE.FIELDSIZE%TYPE,
                     iINPUTFULLSIZE FIELDS_STRUCTURE.INPUTFULLSIZE%TYPE,
                     iFIELDORDER FIELDS_STRUCTURE.FIELDORDER%TYPE,
                     iSHOWTYPE FIELDS_STRUCTURE.SHOWTYPE%TYPE) 
      RETURN CLOB; 
   FUNCTION delete_by_id (iID FIELDS_STRUCTURE.ID%TYPE) RETURN CLOB;
   FUNCTION delete_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN CLOB;
   FUNCTION get_ID  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN FIELDS_STRUCTURE.ID%TYPE;
   FUNCTION get_Structure  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE) RETURN CLOB;
   FUNCTION Select_ (iInput CLOB) RETURN CLOB;   
END p_FIELDS_STRUCTURE;
/

create PACKAGE BODY p_FIELDS_STRUCTURE AS 
   FUNCTION add_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                  iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                  iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                  iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                  iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                  iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                  iFIELDTIPE FIELDS_STRUCTURE.FIELDTIPE%TYPE,
                  iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                  iFROMDICTIONARYPARRENT FIELDS_STRUCTURE.FROMDICTIONARYPARRENT%TYPE) 
      RETURN XMLtype is
          Begin
           insert into FIELDS_STRUCTURE ( TABLE_NAME,  FIELD_NAME,  DATA_TYPE,  INPUTTYPE,  ISUNIQUE,  FIELDTIPE,  FROMDICTIONARY,  FROMDICTIONARYPARRENT) 
                                 values (iTABLE_NAME, iFIELD_NAME, iDATA_TYPE, iINPUTTYPE, iISUNIQUE, iFIELDTIPE, iFROMDICTIONARY, iFROMDICTIONARYPARRENT);

           EXECUTE IMMEDIATE 'ALTER TABLE '||iTABLE_NAME||' ADD '||iFIELD_NAME||' '||iDATA_TYPE;
           commit;  
           return f_result_xml(0,null);
           EXCEPTION
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
          End;

     
   FUNCTION UPDATE_ (iID FIELDS_STRUCTURE.ID%TYPE,
                     --iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                     iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                     iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                     iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                     iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                     iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                     iFIELDTIPE FIELDS_STRUCTURE.FIELDTIPE%TYPE,
                     iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                     iFROMDICTIONARYPARRENT FIELDS_STRUCTURE.FROMDICTIONARYPARRENT%TYPE) 
      RETURN XMLtype IS
         e_update exception;
         v_err_code number;
         v_err_mes varchar2(100);
         v_TABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE;
         v_FIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE;
         v_DATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE;
         v_FIELDTIPE  FIELDS_STRUCTURE.FIELDTIPE%TYPE;
         Begin
         select   TABLE_NAME,   FIELDTIPE,   FIELD_NAME,   DATA_TYPE
           into v_TABLE_NAME, v_FIELDTIPE, v_FIELD_NAME, v_DATA_TYPE
           from FIELDS_STRUCTURE
          where id = iID;
          
         update FIELDS_STRUCTURE
            set --TABLE_NAME = iTABLE_NAME,
                FIELD_NAME = iFIELD_NAME,
                --DATA_TYPE =  iDATA_TYPE,
                INPUTTYPE =  iINPUTTYPE,
                ISUNIQUE  =  iISUNIQUE,
                USEFORFILTER = iUSEFORFILTER,
                FIELDTIPE =  iFIELDTIPE,
                FROMDICTIONARY = iFROMDICTIONARY,
                FROMDICTIONARYPARRENT = iFROMDICTIONARYPARRENT
            where id = iID;
            
          if v_FIELDTIPE in ('SYSTEM','FIXED') 
            then  v_err_code := -20001;
                  v_err_mes :=  'FIELDTIPE field cannot be SYSTEM or FIXED!';
                  raise e_update; 
          elsif v_DATA_TYPE != iDATA_TYPE 
            then v_err_code := -20001;
                 v_err_mes :=  'DATA_TYPE cannot be modified! Use drop and add function.';
                 raise e_update;
          elsif v_FIELD_NAME != iFIELD_NAME then
            EXECUTE IMMEDIATE 'ALTER TABLE '||v_TABLE_NAME||' RENAME COLUMN '||v_FIELD_NAME||' TO '||iFIELD_NAME;
          end if;
          
           commit;  
           return f_result_xml(0,null);
           EXCEPTION 
               WHEN e_update THEN
               rollback;
              return f_result_xml(v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100));            
         End; 

   FUNCTION delete_ (iID FIELDS_STRUCTURE.ID%TYPE) RETURN XMLtype IS
         e_delete exception;
         v_cnt number;
         v_TABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE;
         v_FIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE;
         v_FIELDTIPE  FIELDS_STRUCTURE.FIELDTIPE%TYPE;
         v_err_code number;
         v_err_mes varchar2(100);
      Begin
         select   TABLE_NAME,   FIELD_NAME,   FIELDTIPE
           into v_TABLE_NAME, v_FIELD_NAME, v_FIELDTIPE
           from FIELDS_STRUCTURE
          where id = iID;
        EXECUTE IMMEDIATE 'select count( '||v_FIELD_NAME||' ) from '||v_TABLE_NAME  into v_cnt;
        if     v_FIELDTIPE in ('SYSTEM','FIXED') then 
           v_err_code := -20001;
           v_err_mes :=  'FIELDTIPE field cannot be SYSTEM or FIXED!';           
           raise e_delete;        
        elsif  v_cnt != 0 then
           v_err_code := -20001;
           v_err_mes :=  v_FIELD_NAME||' field into '||v_TABLE_NAME||' table have '||to_char(v_cnt)||' not null rows.';           
           raise e_delete;
        end if;
        delete 
          from FIELDS_STRUCTURE
          where id = iID;
        
        EXECUTE IMMEDIATE 'ALTER TABLE '||v_TABLE_NAME||' drop column '||v_FIELD_NAME;

           commit;  
           return f_result_xml(0,null);
           EXCEPTION 
               WHEN e_delete THEN
              return f_result_xml(v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100));         
      End;

   FUNCTION delete_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN XMLtype IS
      v_id FIELDS_STRUCTURE.ID%TYPE;
      Begin
       v_id := get_ID(iTABLE_NAME, iFIELD_NAME);
       return delete_(v_id);
      End;

   FUNCTION get_ID (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN FIELDS_STRUCTURE.ID%TYPE IS
      v_id FIELDS_STRUCTURE.ID%TYPE := -1;
      Begin
       select id 
         into v_id
         from FIELDS_STRUCTURE
        where TABLE_NAME = iTABLE_NAME and FIELD_NAME = iFIELD_NAME;
       return v_id;
      EXCEPTION 
          WHEN OTHERS THEN
          return v_id;                
      End;
   FUNCTION get_Structure  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE) 
      RETURN XMLtype IS
      v_result XMLtype;      
      v_where varchar(4000) := ' where (1=1) ';
     Begin
      if iTABLE_NAME is not null then v_where := v_where || ' and TABLE_NAME = '''||iTABLE_NAME||''' ';
      end if;
      
      EXECUTE IMMEDIATE 'select xmlelement("result",  xmlagg(XMLelement("Row",xmlattributes(UPPER(Table_name) as "Table_name"), xmlforest(UPPER(Field_Name) "Field_Name", UPPER(Data_Type) "Data_type"))))
                        from FIELDS_STRUCTURE '||v_where into v_result;
      return v_result;
      EXCEPTION
           WHEN OTHERS THEN
      return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100));      
     End; 
END p_FIELDS_STRUCTURE;
/

