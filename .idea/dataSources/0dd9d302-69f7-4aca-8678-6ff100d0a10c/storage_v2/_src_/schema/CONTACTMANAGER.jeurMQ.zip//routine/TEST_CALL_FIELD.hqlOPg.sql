create PROCEDURE test_Call_Field (xid NUMBER) as 
  BEGIN
    Select * from FIELDS_STRUCTURE where id = xid;
  END;
/

