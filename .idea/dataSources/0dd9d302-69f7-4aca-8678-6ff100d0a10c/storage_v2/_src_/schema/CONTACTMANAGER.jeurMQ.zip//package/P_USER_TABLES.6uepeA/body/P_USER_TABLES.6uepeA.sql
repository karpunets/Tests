create PACKAGE BODY P_USER_TABLES AS 
   FUNCTION add_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iInput CLOB) 
      RETURN CLOB IS
     v_Fields_str varchar2(4000) := 'insert into ';
     v_Value_str  varchar2(32000) := ' values ( ';
     v_tmp        varchar(32000);
     v_err_code   number := 0;
     v_err_mes    varchar2(100);
     v_Tab_fields XMLType;
     e_add        exception;
     vID          FIELDS_STRUCTURE.ID%TYPE;
     Begin
      execute immediate q'[alter session set nls_date_format = 'dd.mm.yyyy hh24:mi:ss']';
       v_Tab_fields := XMLtype(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME));
       if v_Tab_fields is not null then
        v_Fields_str := v_Fields_str||iTABLE_NAME||' ( ';
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type, field.f_value
                      FROM XMLTable('//ROWSET/ROW' passing v_Tab_fields
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE') tab,
                           XMLTable('ROW/*'        passing XMLtype(iInput)
                            columns f_name  varchar2(4000) path 'name(.)',
                                    f_value varchar2(4000) path '.') field
                     where tab.FIELD_NAME = field.f_name and tab.FIELD_NAME != 'ID')
        LOOP
              if    rec.f_value is null then
                v_tmp := ' null , ';     
--              elsif rec.Data_type = 'DATE' then
--                v_tmp := ' to_date( '''||rec.f_value||''' , ''dd.mm.yyyy hh24:mi:ss''), ';
--              elsif rec.Data_type like 'NUMBER%' then
--                v_tmp := ' to_number( '''||rec.f_value||''' ), ';
              else  
                v_tmp := ' '''||rec.f_value||''', ';
              end if;     
              v_Fields_str := v_Fields_str || rec.Field_Name || ' , ';
              v_Value_str := v_Value_str || v_tmp;
        END LOOP;
            v_Fields_str := rTrim(v_Fields_str,', ') || ' ) ';
            v_Value_str := rTrim(v_Value_str,', ') || ' ) ';
--            EXECUTE IMMEDIATE v_Fields_str || v_Value_str;
            EXECUTE IMMEDIATE v_Fields_str || v_Value_str||' returning ID into :1' returning into vID;
        commit;
       else
         v_err_code := -20001;
         v_err_mes := 'The '||iTABLE_NAME||' table is wrong.';
         raise e_add;
       end if;             
        return Select_(iTABLE_NAME, '<ROW><WHERE> Where ID = '||vID||' </WHERE></ROW>', null, null);
        EXCEPTION
             WHEN e_add THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);           
             WHEN OTHERS THEN
              rollback;
           return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;  
   FUNCTION Select_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iInput CLOB, iSkipRows number, iMaxRows number)
      RETURN CLOB IS
      v_result CLOB;
      v_tmp    varchar(32000);
      v_Where  varchar(32000);
      v_Order  varchar(32000);
      v_ctx    dbms_xmlgen.ctxHandle;      
     Begin
        execute immediate q'[alter session set nls_date_format = 'dd.mm.yyyy hh24:mi:ss']';  
             select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
                    extractValue(value(t),'ROW/ORDER[position()=1]') 
               into v_Where,
                    v_Order
               from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;
               
--        FOR rec IN (select extractValue(value(t),'ROW/FIELD_NAME') Field_Name, extractValue(value(t),'ROW/DATA_TYPE') Data_type
--                    from table(XMLSequence(XMLType(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME)).extract('//ROWSET/ROW'))) t)
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type
                      FROM XMLTable('//ROWSET/ROW' passing XMLType(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME))
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab
                    order by tab.FIELDORDER)
        LOOP
--          if    rec.Data_type = 'DATE' then
--           v_tmp := v_tmp ||' to_char( '||rec.Field_Name||' , ''dd.mm.yyyy hh24:mi:ss'') '||UPPER(rec.Field_Name)||', ';
          --elsif rec.Data_type = 'NUMBER' then
           --v_tmp := v_tmp ||' to_char( '||rec.Field_Name||' ) '||UPPER(rec.Field_Name)||', ';
--          else  
           v_tmp := v_tmp ||' '||rec.Field_Name||' '||UPPER(rec.Field_Name)||', ';
--          end if;
        END LOOP;

          v_ctx := dbms_xmlgen.newContext('select '||rTrim(v_tmp,', ')||' from '||iTABLE_NAME||' '||v_Where||' '||v_Order );
          if iMaxRows  is not null then DBMS_XMLGEN.SETMAXROWS ( v_ctx, iMaxRows);  end if;
          if iSkipRows is not null then DBMS_XMLGEN.SETSKIPROWS (v_ctx, iSkipRows); end if;          
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);                          
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
     End;      
   
   FUNCTION Update_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iID FIELDS_STRUCTURE.ID%TYPE, iInput CLOB)
      RETURN CLOB IS
      v_tmp        varchar2(32000);
--      v_Value      varchar2(4000);
      v_err_code   number := 0;
      v_err_mes    varchar2(100);
      v_Tab_fields XMLType;
      e_update     exception;
     Begin
       execute immediate q'[alter session set nls_date_format = 'dd.mm.yyyy hh24:mi:ss']';     
       v_Tab_fields := XMLtype(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME));
       if v_Tab_fields is not null then
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type, field.f_value
                      FROM XMLTable('//ROWSET/ROW' passing v_Tab_fields
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab,
                           XMLTable('ROW/*'        passing XMLtype(iInput)
                            columns f_name  varchar2(4000) path 'name(.)',
                                    f_value varchar2(4000) path '.') field
                     where tab.FIELD_NAME = field.f_name and tab.FIELD_NAME != 'ID'
                     order by tab.FIELDORDER)
        LOOP
              if    rec.f_value is null then
                v_tmp := v_tmp || rec.Field_Name|| ' = null , ';     
--              elsif rec.Data_type = 'DATE' then
--                v_tmp := v_tmp || rec.Field_Name||' = to_date( '''||rec.f_value||''' , ''dd.mm.yyyy hh24:mi:ss''), ';
--              elsif rec.Data_type like 'NUMBER%' then
--                v_tmp := v_tmp || rec.Field_Name||' = to_number( '''||rec.f_value||''' ), ';
              else  
                v_tmp := v_tmp || rec.Field_Name||' = '''||rec.f_value||''', ';
              end if;        
        END LOOP;
                
            if v_tmp is not null then
             EXECUTE IMMEDIATE 'update '||iTABLE_NAME||' set '||rTrim(v_tmp,', ')||' where ID = '||to_char(iID);
            end if;
        commit;
       else
         v_err_code := -20001;
         v_err_mes := 'The '||iTABLE_NAME||' table is wrong.';
         raise e_update;
       end if;     
        return Select_(iTABLE_NAME, '<ROW><WHERE> Where ID = '||iID||' </WHERE></ROW>', null, null);
        EXCEPTION
             WHEN e_update THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);        
             WHEN OTHERS THEN
              rollback;
           return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));      
     End;    
   FUNCTION Delete_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iID FIELDS_STRUCTURE.ID%TYPE)
      RETURN CLOB IS
         v_ID number;
         v_err_code number := 0;
         v_err_mes varchar2(100);
         e_delete exception;
         v_cnt number;
     Begin
        if p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME) is not null then
          /*----- Begin ------*/
          if iTABLE_NAME = 'CLIENTS' then
           select count(id)
             into v_cnt 
             from REQUEST
            where CLIENTSID = iID;
           if v_cnt > 0 then
            v_err_code := -20001;
            v_err_mes := 'The REQUEST table have '||v_cnt||' rows for '||iID||' CLIENTS.ID.';
            raise e_delete;
           end if;
          end if;
          /*----- End   ------*/
         Execute Immediate 'select id from '||iTABLE_NAME||' where ID = '||to_char(iID) Into v_ID;
         EXECUTE IMMEDIATE 'delete from '||iTABLE_NAME||' where ID = '||to_char(iID);
         commit;
        else 
         v_err_code := -20001;
         v_err_mes := 'The '||iTABLE_NAME||' table is wrong.';
         raise e_delete;
        end if;
            
        return f_result_xml(iID, null, null);
        EXCEPTION
             WHEN e_delete THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);        
             WHEN OTHERS THEN
              rollback;
           return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;
   FUNCTION Select_Req_Cli (iInput CLOB, iSkipRows number, iMaxRows number)
      RETURN CLOB is
      v_result CLOB;
      v_tmp_R    varchar(32000) := ' XMLForest( ';
      v_tmp_C    varchar(32000) := ' XMLForest( ';
      v_Where  varchar(32000);
      v_Order  varchar(32000);
      v_ctx    dbms_xmlgen.ctxHandle;
     Begin
       execute immediate q'[alter session set nls_date_format = 'dd.mm.yyyy hh24:mi:ss']';     
--              Begin
               select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
                      extractValue(value(t),'ROW/ORDER[position()=1]') 
               into v_Where, 
                    v_Order
               from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;
--              EXCEPTION
--                WHEN OTHERS THEN
--                 v_Where := ' Where 1 = 1 ';
--              End;
         if v_Where is null then  v_Where := ' Where 1 = 1 '; end if;
  
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type
                      FROM XMLTable('//ROWSET/ROW' passing XMLType(p_FIELDS_STRUCTURE.get_Structure('REQUEST'))
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab
                    order by tab.FIELDORDER)
        LOOP
          if    rec.Data_type = 'DATE' then
           v_tmp_R := v_tmp_R ||' to_char( REQUEST.'||rec.Field_Name||' , ''dd.mm.yyyy hh24:mi:ss'') '||UPPER(rec.Field_Name)||', ';
          else  
           v_tmp_R := v_tmp_R ||' REQUEST.'||rec.Field_Name/*||' R'||UPPER(rec.Field_Name)*/||', ';
          end if;
        END LOOP;
        v_tmp_R := rTrim(v_tmp_R, ', ')||') REQUEST, ';
        
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type
                      FROM XMLTable('//ROWSET/ROW' passing XMLType(p_FIELDS_STRUCTURE.get_Structure('CLIENTS'))
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab
                    order by tab.FIELDORDER)
        LOOP
          if    rec.Data_type = 'DATE' then
           v_tmp_C := v_tmp_C ||' to_char( CLIENTS.'||rec.Field_Name||' , ''dd.mm.yyyy hh24:mi:ss'') '||UPPER(rec.Field_Name)||', ';
          else  
           v_tmp_C := v_tmp_C ||' CLIENTS.'||rec.Field_Name/*||' C'||UPPER(rec.Field_Name)*/||', ';
          end if;
        END LOOP;
        v_tmp_C := rTrim(v_tmp_C, ', ')||') CLIENTS ';

          v_ctx := dbms_xmlgen.newContext('select '||/*rTrim(v_tmp,', ')*/v_tmp_R||v_tmp_C||' from  REQUEST, CLIENTS '||v_Where||' and REQUEST.CLIENTSID =  CLIENTS.ID '||v_Order );
          if iMaxRows  is not null then DBMS_XMLGEN.SETMAXROWS ( v_ctx, iMaxRows);  end if;
          if iSkipRows is not null then DBMS_XMLGEN.SETSKIPROWS (v_ctx, iSkipRows); end if;           
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);
                                        
          return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
     End;       
  
END P_USER_TABLES;
/

