create PACKAGE P_DICTIONARYS AS 
   FUNCTION add_ (iCODE DICTIONARYS.CODE%TYPE,
                  iName DICTIONARYS.NAME%TYPE,
                  iParentID  DICTIONARYS.ParentID%TYPE,
                  iText  DICTIONARYS.Text%TYPE,
                  iURL   DICTIONARYS.URL%TYPE) 
      RETURN CLOB;
   FUNCTION Select_ (iID        DICTIONARYS.ID%TYPE, 
                     iCODE      DICTIONARYS.CODE%TYPE, 
                     iName      DICTIONARYS.NAME%TYPE, 
                     iParentID  DICTIONARYS.ParentID%TYPE)
      RETURN CLOB;      
      
   FUNCTION Delete_ (iID DICTIONARYS.ID%TYPE)
      RETURN CLOB;

   Function get_ID  (iCODE DICTIONARYS.CODE%TYPE,
                     iName DICTIONARYS.NAME%TYPE,
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iText  DICTIONARYS.Text%TYPE,
                     iURL   DICTIONARYS.URL%TYPE)
      return DICTIONARYS.ID%TYPE;
      
   FUNCTION Update_ (iID DICTIONARYS.ID%TYPE,
                     iCODE DICTIONARYS.CODE%TYPE,
                     iName DICTIONARYS.NAME%TYPE,
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iText  DICTIONARYS.Text%TYPE,
                     iURL   DICTIONARYS.URL%TYPE)
      RETURN CLOB;
   FUNCTION DictionaryList(iName DICTIONARYS.NAME%TYPE)
      RETURN CLOB;
   FUNCTION Tree_for_ID(iID DICTIONARYS.ID%TYPE)
      RETURN CLOB;                           
END P_DICTIONARYS;
/

create PACKAGE BODY P_DICTIONARYS AS 
    FUNCTION add_ (iCODE DICTIONARYS.CODE%TYPE,
                  iName DICTIONARYS.NAME%TYPE,
                  iParentCode  DICTIONARYS.ParentCode%TYPE,
                  iText  DICTIONARYS.Text%TYPE,
                  iURL   DICTIONARYS.URL%TYPE) 
      RETURN XMLtype is 
     BEGIN
          insert into DICTIONARYS ( CODE,  Name,  ParentCode,  Text,  URL)
                           values (iCODE, iName, iParentCode, iText, iURL);

           commit;  
           return f_result_xml(0,null);
           EXCEPTION
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     END;
      
    FUNCTION Select_ (iCODE DICTIONARYS.CODE%TYPE, iParentCode  DICTIONARYS.ParentCode%TYPE)
      RETURN XMLtype IS
     Begin
     return Select_ (iCODE, null, iParentCode);
           EXCEPTION
               WHEN OTHERS THEN
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100));       
     End;
    FUNCTION Select_ (iCODE DICTIONARYS.CODE%TYPE, 
                     iName DICTIONARYS.NAME%TYPE, 
                     iParentCode  DICTIONARYS.ParentCode%TYPE)
      RETURN XMLtype IS
      v_result XMLtype;
      v_where varchar(4000) := ' where (1=1) ';
     Begin
      if iName is not null then v_where := v_where || ' and Name = '''||iName||''' ';
      end if;
      if iCode is not null then 
       v_where := v_where || ' and code = '''||iCode||''' ';
      end if;
      if iParentCode is null then v_where := v_where || ' and ParentCode is null ';
      elsif iParentCode != '-' then v_where := v_where || ' and ParentCode = '''||iParentCode||''' ';
      end if;
      
          EXECUTE IMMEDIATE 'select xmlelement("result",  xmlagg(XMLelement("Row",xmlattributes(ID as "ID"), xmlforest(Code "Code", Name "Name", ParentCode "ParentCode", Text "Text", URL "URL", (select count(d2.id) from DICTIONARYS d2 where d2.PARENTCODE = d.code) "CountChild"))))
 from DICTIONARYS d '||v_where into v_result;
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;
    
    FUNCTION Delete_ (iCODE DICTIONARYS.CODE%TYPE)
      RETURN XMLtype is
      v_cnt number;
      v_err_code NUMBER;
      v_err_mes varchar(100);
      e_delete exception; 
     Begin
            select count(id)
              into v_cnt
              from DICTIONARYS
             where ParentCode = iCode
               and Code != iCode;
             
        if v_cnt > 0 then 
          v_err_code := -20001;
          v_err_mes := 'You can not delete '||iCode||' code. The code have '||to_char(v_cnt)||' childs.';
          raise e_delete;
        end if;
        
            delete
              from DICTIONARYS
             where Code = iCODE;

           commit;  
           return f_result_xml(0,null);
           EXCEPTION
               WHEN e_delete THEN
              return f_result_xml(v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;
    Function get_ID  (iCODE DICTIONARYS.CODE%TYPE)
      return DICTIONARYS.ID%TYPE is
      v_ID DICTIONARYS.ID%TYPE := -1;
     Begin
       select ID
         into v_ID
         from DICTIONARYS
        where Code = iCODE;
       return v_ID;
      EXCEPTION 
          WHEN OTHERS THEN
          return v_id;                     
     End;
    
    FUNCTION Update_ (iID DICTIONARYS.ID%TYPE,
                      iCODE DICTIONARYS.CODE%TYPE,
                      iName DICTIONARYS.NAME%TYPE,
                      iParentCode  DICTIONARYS.ParentCode%TYPE,
                      iText  DICTIONARYS.Text%TYPE,
                      iURL   DICTIONARYS.URL%TYPE)
     RETURN XMLtype is
      v_err_code NUMBER;
      v_err_mes varchar(100);
      e_update exception;
      v_code DICTIONARYS.CODE%TYPE;
      v_cnt number;
     Begin
      select   Code
        into v_Code
        from DICTIONARYS
       where ID = iID; 
       
      if v_Code != iCode then
       select count(id)
         into v_cnt
         from DICTIONARYS
        where ParentCode = v_Code 
          and Code != v_Code;
        if v_cnt > 0 then 
          v_err_code := -20001;
          v_err_mes := 'You can not update '||v_Code||' code. The code have '||to_char(v_cnt)||' childs.';
          raise e_update;
        end if; 
      end if;
      
      update DICTIONARYS
         set  CODE = iCODE,  
              Name = iName,
              ParentCode = iParentCode,
              Text = iText,
              URL = iURL
       where ID = iID;

           commit;  
           return f_result_xml(0,null);
           EXCEPTION
               WHEN e_update THEN
              return f_result_xml(v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100));         
     End;
    FUNCTION DictionaryList (iName DICTIONARYS.NAME%TYPE)
      RETURN XMLtype is
      v_result XMLType;
      v_where varchar2(4000) := ' where (1=1) ';
     Begin
      if iName is not null then v_where := v_where||' and Name like '''||iName||''' '; end if;
      
          EXECUTE IMMEDIATE 'select xmlelement("result",  xmlagg(XMLelement("Row", xmlforest( D.Name as "Name", d.cnt "Count")))) '||
                            ' from (select Name, Count(*) cnt from DICTIONARYS '||v_where||' group by Name) D ' into v_result;
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
              return f_result_xml(SQLCODE, SUBSTR(SQLERRM, 1 , 100));      
     End; 
                       
END P_DICTIONARYS;
/

