create PACKAGE P_DICTIONARYS AS 
   FUNCTION add_ (iCODE DICTIONARYS.CODE%TYPE,
                  iName DICTIONARYS.NAME%TYPE,
                  iParentID  DICTIONARYS.ParentID%TYPE,
                  iText  DICTIONARYS.Text%TYPE,
                  iURL   DICTIONARYS.URL%TYPE,
                  iINFO   DICTIONARYS.INFO%TYPE) 
      RETURN CLOB;
   FUNCTION Select_ (iID        DICTIONARYS.ID%TYPE, 
                     iCODE      DICTIONARYS.CODE%TYPE, 
                     iName      DICTIONARYS.NAME%TYPE, 
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iInput CLOB)
      RETURN CLOB;      
      
   FUNCTION Delete_ (iID DICTIONARYS.ID%TYPE)
      RETURN CLOB;

   Function get_ID  (iCODE DICTIONARYS.CODE%TYPE,
                     iName DICTIONARYS.NAME%TYPE,
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iText  DICTIONARYS.Text%TYPE,
                     iURL   DICTIONARYS.URL%TYPE)
      return DICTIONARYS.ID%TYPE;
      
   FUNCTION Update_ (iID DICTIONARYS.ID%TYPE,
                     iCODE DICTIONARYS.CODE%TYPE,
                     iName DICTIONARYS.NAME%TYPE,
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iText  DICTIONARYS.Text%TYPE,
                     iURL   DICTIONARYS.URL%TYPE,
                     iINFO   DICTIONARYS.INFO%TYPE)
      RETURN CLOB;
   FUNCTION DictionaryList(iName DICTIONARYS.NAME%TYPE)
      RETURN CLOB;
   FUNCTION Tree_for_ID(iID DICTIONARYS.ID%TYPE)
      RETURN CLOB;
   FUNCTION SelectByList(iList varchar2)
      RETURN CLOB;                           
END P_DICTIONARYS;
/

