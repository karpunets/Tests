create PACKAGE P_FIELDRELATIONS AS
   FUNCTION merge_ (iFORFIELD_ID     FIELDRELATIONS.FORFIELD_ID%TYPE,
                    iRELATEDFIELD_ID FIELDRELATIONS.RELATEDFIELD_ID%TYPE,
                    iMAINDICT_ID     FIELDRELATIONS.MAINDICT_ID%TYPE,
                    iRELATEDDICT_IDS FIELDRELATIONS.RELATEDDICT_IDS%TYPE,
                    iREQUIRED        FIELDRELATIONS.REQUIRED%TYPE) 
      RETURN CLOB;      
   FUNCTION Select_ (iInput CLOB)
      RETURN CLOB;      
      
END P_FIELDRELATIONS;
/

create PACKAGE BODY P_FIELDRELATIONS AS 
   FUNCTION put_ (iID              FIELDRELATIONS.ID%TYPE,
                  iFORFIELD_ID     FIELDRELATIONS.FORFIELD_ID%TYPE,
                  iRELATEDFIELD_ID FIELDRELATIONS.RELATEDFIELD_ID%TYPE,
                  iMAINDICT_ID     FIELDRELATIONS.MAINDICT_ID%TYPE,
                  iRELATEDDICT_IDS FIELDRELATIONS.RELATEDDICT_IDS%TYPE,
                  iREQUIRED        FIELDRELATIONS.REQUIRED%TYPE) 
      RETURN CLOB IS
      vID FIELDRELATIONS.ID%TYPE;
      Begin
       if iID is null then
        insert into FIELDRELATIONS ( FORFIELD_ID,  RELATEDFIELD_ID,  MAINDICT_ID,  RELATEDDICT_IDS,  REQUIRED) 
                            values (iFORFIELD_ID, iRELATEDFIELD_ID, iMAINDICT_ID, iRELATEDDICT_IDS, iREQUIRED)
                             returning ID into vID;
       else
         vID := iID;
         update FIELDRELATIONS
            set FORFIELD_ID     = iFORFIELD_ID,
                RELATEDFIELD_ID = iRELATEDFIELD_ID,
                MAINDICT_ID     = iMAINDICT_ID,  
                RELATEDDICT_IDS = iRELATEDDICT_IDS,
                REQUIRED        = iREQUIRED
          where id = iID;
       End if;

       commit;  
       return Select_('<ROW><WHERE> Where ID = '||vID||' </WHERE></ROW>');
       EXCEPTION
           WHEN OTHERS THEN
            rollback;
          return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;  
   FUNCTION Select_ (iInput CLOB)
      RETURN CLOB IS
      v_result CLOB;
      v_Where  varchar(32000);
      v_Order  varchar(32000);
      v_ctx    dbms_xmlgen.ctxHandle;      
     Begin
             select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
                    extractValue(value(t),'ROW/ORDER[position()=1]') 
               into v_Where,
                    v_Order
               from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;
               
          v_ctx := dbms_xmlgen.newContext('select * from FIELDRELATIONS '||v_Where||' '||v_Order );
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);                          
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
     End;      
   

   FUNCTION Delete_ (iID FIELDRELATIONS.ID%TYPE)
      RETURN CLOB IS
         e_delete exception;
         v_err_code number;
         v_err_mes varchar2(100);
         vID FIELDRELATIONS.ID%TYPE;    
     Begin
     select  ID
       into vID
       from FIELDRELATIONS
      Where id = iID;
     
        delete 
          from FIELDRELATIONS
          where id = iID;
        commit;  
        return f_result_xml(iID, null, null);
        EXCEPTION
            WHEN e_delete THEN
              return f_result_xml(null, v_err_code, v_err_mes);         
            WHEN OTHERS THEN
            rollback;
            return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));  
     End;
       
END P_FIELDRELATIONS;
/

