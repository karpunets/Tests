create PACKAGE BODY P_USER_TABLES AS 
   FUNCTION add_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFieldsData CLOB) 
      RETURN CLOB IS
     v_Fields_str varchar2(4000) := 'insert into ';
     v_Value_str  varchar2(32000) := ' values ( ';
     v_tmp        varchar(32000);
     v_err_code   number := 0;
     v_err_mes    varchar2(100);
     v_Tab_fields XMLType;
     e_add        exception;
     vID          FIELDS_STRUCTURE.ID%TYPE;
     Begin
      --execute immediate q'[alter session set nls_date_format = 'dd.mm.yyyy hh24:mi:ss']';
       v_Tab_fields := XMLtype(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME));
       if v_Tab_fields is not null then
        v_Fields_str := v_Fields_str||iTABLE_NAME||' ( ';
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type, field.f_value
                      FROM XMLTable('//ROWSET/ROW' passing v_Tab_fields
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE') tab,
                           XMLTable('ROW/*'        passing XMLtype(iFieldsData)
                            columns f_name  varchar2(4000) path 'name(.)',
                                    f_value varchar2(4000) path '.') field
                     where tab.FIELD_NAME = field.f_name and tab.FIELD_NAME not in (iTABLE_NAME||'_ID', 
                                                                                    iTABLE_NAME||'_STATUS', 
                                                                                    iTABLE_NAME||'_PARID',
                                                                                    iTABLE_NAME||'_DATECREATE',
                                                                                    iTABLE_NAME||'_DATEMODIFY'))
        LOOP
              if    rec.f_value is null then
                v_tmp := ' null , ';     
--              elsif rec.Data_type = 'DATE' then
--                v_tmp := ' to_date( '''||rec.f_value||''' , ''dd.mm.yyyy hh24:mi:ss''), ';
--              elsif rec.Data_type like 'NUMBER%' then
--                v_tmp := ' to_number( '''||rec.f_value||''' ), ';
              else  
                v_tmp := ' '''||rec.f_value||''', ';
              end if;     
              v_Fields_str := v_Fields_str || rec.Field_Name || ' , ';
              v_Value_str := v_Value_str || v_tmp;
        END LOOP;
            v_Fields_str := rTrim(v_Fields_str,', ') || ' ) ';
            v_Value_str := rTrim(v_Value_str,', ') || ' ) ';

            EXECUTE IMMEDIATE v_Fields_str || v_Value_str||' returning '||iTABLE_NAME||'_ID into :1' returning into vID;
        commit;
       else
         v_err_code := -20001;
         v_err_mes := 'The '||iTABLE_NAME||' table is wrong.';
         raise e_add;
       end if;             
        return Select_(iTABLE_NAME, '<ROW><WHERE> Where '||iTABLE_NAME||'_ID = '||vID||' </WHERE></ROW>', null, null);
        EXCEPTION
             WHEN e_add THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);           
             WHEN OTHERS THEN
              rollback;
           return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;  
   FUNCTION Select_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iWhereOrder CLOB, iSkipRows number, iMaxRows number)
      RETURN CLOB IS
      v_result CLOB;
      v_count  number;
      v_tmp    varchar(32000);
      v_Where  varchar(32000);
      v_Order  varchar(32000);
      v_ctx    dbms_xmlgen.ctxHandle;      
     Begin
        --execute immediate q'[alter session set nls_date_format = 'dd.mm.yyyy hh24:mi:ss']';  
             select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
                    extractValue(value(t),'ROW/ORDER[position()=1]') 
               into v_Where,
                    v_Order
               from table(XMLSequence(XMLType(iWhereOrder).extract('//ROW'))) t;
               
--        FOR rec IN (select extractValue(value(t),'ROW/FIELD_NAME') Field_Name, extractValue(value(t),'ROW/DATA_TYPE') Data_type
--                    from table(XMLSequence(XMLType(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME)).extract('//ROWSET/ROW'))) t)
--        FOR rec IN (SELECT tab.Field_Name, tab.Data_type
--                      FROM XMLTable('//ROWSET/ROW' passing XMLType(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME))
--                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
--                                    Data_type  varchar2(4000) path 'DATA_TYPE',
--                                    FIELDORDER number path 'FIELDORDER') tab
--                    order by tab.FIELDORDER)
--        LOOP
--           v_tmp := v_tmp ||' '||UPPER(rec.Field_Name)||', ';
--        END LOOP;

          v_ctx := dbms_xmlgen.newContext('select * '/*||rTrim(v_tmp,', ')*/||' from '||iTABLE_NAME||' '||v_Where||' '||v_Order );
          if iMaxRows  is not null then DBMS_XMLGEN.SETMAXROWS ( v_ctx, iMaxRows);  end if;
          if iSkipRows is not null then DBMS_XMLGEN.SETSKIPROWS (v_ctx, iSkipRows); end if;          
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
--       if v_result is not null then
--         EXECUTE IMMEDIATE 'select count(*) from '||iTABLE_NAME||' '||v_Where into v_count;
--         SELECT insertchildxml(XMLType(v_result), 'ROWSET', '@Count', v_count).getClobVal() INTO v_result FROM dual;
--         --SELECT XMLSerialize(document insertchildxml(XMLType(v_result), 'ROWSET', '@Count', v_count) as clob) INTO v_result FROM dual;
--       end if;  
                   dbms_xmlgen.closeContext(v_ctx);                          
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
     End;      
   
   FUNCTION Update_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iID FIELDS_STRUCTURE.ID%TYPE, iFieldsData CLOB)
      RETURN CLOB IS
      v_tmp        varchar2(32000);
      --v_ins_str    varchar2(32000) := ' insert into ';
      --v_ins_val    varchar2(32000) := ' select ';      
--      v_Value      varchar2(4000);
      v_err_code   number := 0;
      v_err_mes    varchar2(100);
      v_Tab_fields XMLType;
      v_date       Date := sysdate;
      e_update     exception;
     Begin
     
       v_Tab_fields := XMLtype(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME));
       if v_Tab_fields is not null then
--        v_ins_str := v_ins_str||iTABLE_NAME||' ( '||iTABLE_NAME||'_STATUS, '||iTABLE_NAME||'_PARID, '|| iTABLE_NAME||'_DATECREATE, '|| iTABLE_NAME||'_DATEMODIFY, ';
--        v_ins_val := v_ins_val||'2, '||iID||', '''||v_date||''', '|| iTABLE_NAME||'_DATEMODIFY, ';
        FOR rec IN (SELECT tab.Field_Name, tab.Data_type, field.f_value
                      FROM XMLTable('//ROWSET/ROW' passing v_Tab_fields
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab,
                           XMLTable('ROW/*'        passing XMLtype(iFieldsData)
                            columns f_name  varchar2(4000) path 'name(.)',
                                    f_value varchar2(4000) path '.') field
                     where tab.FIELD_NAME = field.f_name and tab.FIELD_NAME not in (iTABLE_NAME||'_ID', 
                                                                                    iTABLE_NAME||'_STATUS', 
                                                                                    iTABLE_NAME||'_PARID',
                                                                                    iTABLE_NAME||'_DATECREATE',
                                                                                    iTABLE_NAME||'_DATEMODIFY')
                     order by tab.FIELDORDER)
        LOOP
--            v_ins_str := v_ins_str||rec.Field_Name ||', ';
--            v_ins_val := v_ins_val||rec.Field_Name ||', ';
 
                v_tmp := v_tmp || rec.Field_Name||' = '''||rec.f_value||''', ';
        END LOOP;
  
            if v_tmp is not null then
             Add_Hist(iTABLE_NAME, iID, v_Tab_fields, v_date);
             --EXECUTE IMMEDIATE rTrim(v_ins_str,', ')||') '||rTrim(v_ins_val,', ')||' from '||iTABLE_NAME||' where '||iTABLE_NAME||'_ID = '||iID;
             EXECUTE IMMEDIATE 'update '||iTABLE_NAME||' set '||iTABLE_NAME||'_DATEMODIFY = '''||v_date||''', '||rTrim(v_tmp,', ')||' where '||iTABLE_NAME||'_ID = '||to_char(iID);
            end if;
        commit;
       else
         v_err_code := -20001;
         v_err_mes := 'The '||iTABLE_NAME||' table is wrong.';
         raise e_update;
       end if;     
        return Select_(iTABLE_NAME, '<ROW><WHERE> Where '||iTABLE_NAME||'_ID = '||iID||' </WHERE></ROW>', null, null);
        EXCEPTION
             WHEN e_update THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);        
             WHEN OTHERS THEN
              rollback;
           return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));      
     End;    
   FUNCTION Delete_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iID FIELDS_STRUCTURE.ID%TYPE)
      RETURN CLOB IS
         v_ID number;
         v_err_code number := 0;
         v_err_mes varchar2(100);
         e_delete exception;
         v_date date := sysdate;
         v_cnt number;
         v_Tab_fields XMLType;
         v_tmp        varchar2(32000);
         v_ins_str    varchar2(32000);
         v_ins_val    varchar2(32000);    
     Begin
       v_Tab_fields := XMLtype(p_FIELDS_STRUCTURE.get_Structure(iTABLE_NAME));
       if v_Tab_fields is not null then
        Execute Immediate 'select '||iTABLE_NAME||'_ID from '||iTABLE_NAME||' where '||iTABLE_NAME||'_ID = '||to_char(iID) Into v_ID;
          /*----- Begin ------*/
          if iTABLE_NAME = 'CLIENTS' then
           select count(REQUESTS_id)
             into v_cnt 
             from REQUESTS
            where REQUESTS_CLIENTSID = iID
              and REQUESTS_STATUS = 1;
           if v_cnt > 0 then
            v_err_code := -20001;
            v_err_mes := 'The REQUEST table have '||v_cnt||' rows for '||iID||' CLIENTS_ID.';
            raise e_delete;
           end if;
          end if;
          /*----- End   ------*/

/*        v_ins_str := v_ins_str||iTABLE_NAME||' ( '||iTABLE_NAME||'_STATUS, '||iTABLE_NAME||'_PARID, '|| iTABLE_NAME||'_DATECREATE, '|| iTABLE_NAME||'_DATEMODIFY, ';
        v_ins_val := v_ins_val||'2, '||iID||', '''||v_date||''', '|| iTABLE_NAME||'_DATEMODIFY, ';
        FOR rec IN (SELECT tab.Field_Name
                      FROM XMLTable('//ROWSET/ROW' passing v_Tab_fields
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab
                     where                                   tab.FIELD_NAME not in (iTABLE_NAME||'_ID', 
                                                                                    iTABLE_NAME||'_STATUS', 
                                                                                    iTABLE_NAME||'_PARID',
                                                                                    iTABLE_NAME||'_DATECREATE',
                                                                                    iTABLE_NAME||'_DATEMODIFY')
                     order by tab.FIELDORDER)
        LOOP
            v_ins_str := v_ins_str||rec.Field_Name ||', ';
            v_ins_val := v_ins_val||rec.Field_Name ||', ';
        END LOOP;
         EXECUTE IMMEDIATE 'insert into '||rTrim(v_ins_str,', ')||') select '||rTrim(v_ins_val,', ')||' from '||iTABLE_NAME||' where '||iTABLE_NAME||'_ID = '||iID;
*/
         Add_Hist(iTABLE_NAME, iID, v_Tab_fields, v_date);
         EXECUTE IMMEDIATE 'update '||iTABLE_NAME||' set '||iTABLE_NAME||'_STATUS = 0, '||iTABLE_NAME||'_DATEMODIFY = '''||v_date||''' where '||iTABLE_NAME||'_ID = '||to_char(iID);
         commit;
        else 
         v_err_code := -20001;
         v_err_mes := 'The '||iTABLE_NAME||' table is wrong.';
         raise e_delete;
        end if;
            
        return f_result_xml(iID, null, null);
        EXCEPTION
             WHEN e_delete THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);        
             WHEN OTHERS THEN
              rollback;
           return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;
   FUNCTION Count_  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iWhereOrder CLOB)
      RETURN CLOB IS
      v_result CLOB;
      v_Where  varchar(32000);
      v_Order  varchar(32000);
      v_ctx    dbms_xmlgen.ctxHandle;
     Begin
               select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
                      extractValue(value(t),'ROW/ORDER[position()=1]') 
               into v_Where, 
                    v_Order
               from table(XMLSequence(XMLType(iWhereOrder).extract('//ROW'))) t;
               --if v_Where is null then  v_Where := ' Where 1 = 1 '; end if;
          v_ctx := dbms_xmlgen.newContext('select count(*) COUNT from  '||iTABLE_NAME||' '||v_Where );
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);
                                        
          return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));               
     End;     

   PROCEDURE Add_Hist (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iID FIELDS_STRUCTURE.ID%TYPE, iTab_fields XMLType, iDate date)
   IS
    v_Fields varchar(32000);
    vID number;
   Begin
   EXECUTE IMMEDIATE 'select '||iTABLE_NAME||'_ID '||' from '||iTABLE_NAME||' where '||iTABLE_NAME||'_ID = '||iID||' and '||iTABLE_NAME||'_STATUS = 1 ' into vID;
   SELECT LISTAGG(tab.Field_Name, ', ') WITHIN GROUP (ORDER BY Field_Name)
     into v_Fields 
     FROM XMLTable('//ROWSET/ROW' passing iTab_fields
                                  columns Field_Name varchar2(4000) path 'FIELD_NAME') tab
    where tab.FIELD_NAME not in (iTABLE_NAME||'_ID', 
                                 iTABLE_NAME||'_STATUS', 
                                 iTABLE_NAME||'_PARID',
                                 iTABLE_NAME||'_DATECREATE');
                                 
    EXECUTE IMMEDIATE 'insert into '||iTABLE_NAME||' ( '||iTABLE_NAME||'_STATUS, '||iTABLE_NAME||'_PARID, '|| iTABLE_NAME||'_DATECREATE, '||v_Fields||' ) '||
                                               ' select 2, '||iID||', '''||iDate||''', '||v_Fields||' from '||iTABLE_NAME||' where '||iTABLE_NAME||'_ID = '||iID;                                                                             
   End;    
  
END P_USER_TABLES;
/

