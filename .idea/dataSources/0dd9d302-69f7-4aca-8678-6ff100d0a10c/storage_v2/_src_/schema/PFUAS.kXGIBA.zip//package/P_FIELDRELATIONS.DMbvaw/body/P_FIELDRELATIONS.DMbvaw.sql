create PACKAGE BODY P_FIELDRELATIONS AS
  FUNCTION merge_ (iFORFIELD_ID     FIELDRELATIONS.FORFIELD_ID%TYPE,
                   iRELATEDFIELD_ID FIELDRELATIONS.RELATEDFIELD_ID%TYPE,
                   iMAINDICT_ID     FIELDRELATIONS.MAINDICT_ID%TYPE,
                   iRELATEDDICT_IDS FIELDRELATIONS.RELATEDDICT_IDS%TYPE,
                   iREQUIRED        FIELDRELATIONS.REQUIRED%TYPE)
    RETURN CLOB IS
    vID FIELDRELATIONS.ID%TYPE;
    vCount number;
    Begin
      select max(FR.ID), count(*)
      into vID, vCount
      from FIELDRELATIONS FR
      Where FR.FORFIELD_ID = iFORFIELD_ID and FR.RELATEDFIELD_ID = iRELATEDFIELD_ID and FR.MAINDICT_ID = iMAINDICT_ID;

      MERGE INTO FIELDRELATIONS FR
      USING (SELECT iFORFIELD_ID F_ID, iRELATEDFIELD_ID R_ID, iMAINDICT_ID M_ID, iRELATEDDICT_IDS R_IDS, nvl(iREQUIRED ,0) R_ FROM dual) iT
      ON (FR.FORFIELD_ID = iT.F_ID and FR.RELATEDFIELD_ID = iT.R_ID and FR.MAINDICT_ID = iT.M_ID)
      WHEN MATCHED THEN UPDATE SET FR.RELATEDDICT_IDS = iT.R_IDS, FR.REQUIRED = iT.R_
        DELETE WHERE (iT.R_IDS is null and iT.R_ = 0 )
      WHEN NOT MATCHED THEN INSERT (FR.FORFIELD_ID,  FR.RELATEDFIELD_ID,  FR.MAINDICT_ID,  FR.RELATEDDICT_IDS,  FR.REQUIRED)
      VALUES (iT.F_ID, iT.R_ID, iT.M_ID, iT.R_IDS, iT.R_);

      commit;
      return nvl(Select_('<ROW><WHERE> Where FORFIELD_ID = '||iFORFIELD_ID||' and RELATEDFIELD_ID = '||iRELATEDFIELD_ID||' and MAINDICT_ID = '||iMAINDICT_ID||' </WHERE></ROW>'),
                 f_result_xml(vID, null, null));
      EXCEPTION
      WHEN OTHERS THEN
      rollback;
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;
  FUNCTION Select_ (iInput CLOB)
    RETURN CLOB IS
    v_result CLOB;
    v_Where  varchar(32000);
    v_Order  varchar(32000);
    v_ctx    dbms_xmlgen.ctxHandle;
    Begin
      select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
        extractValue(value(t),'ROW/ORDER[position()=1]')
      into v_Where,
        v_Order
      from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;

      v_ctx := dbms_xmlgen.newContext('select * from FIELDRELATIONS '||v_Where||' '||v_Order );
      dbms_xmlgen.SETNULLHANDLING(v_ctx,2);
      v_result := dbms_xmlgen.getxml(v_ctx);
      dbms_xmlgen.closeContext(v_ctx);
      return v_result;
      EXCEPTION
      WHEN OTHERS THEN
      dbms_xmlgen.closeContext(v_ctx);
      return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;

END P_FIELDRELATIONS;
/

