create PACKAGE p_FIELDS_STRUCTURE AS 
   FUNCTION add_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                  iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                  iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                  iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                  iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                  iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                  iFIELDTYPE FIELDS_STRUCTURE.FIELDTYPE%TYPE,
                  iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                  iRELATION_FIELD FIELDS_STRUCTURE.RELATION_FIELD%TYPE,
                  iTITLE FIELDS_STRUCTURE.TITLE%TYPE,
                  iFIELDSIZE FIELDS_STRUCTURE.FIELDSIZE%TYPE,
                  iINPUTFULLSIZE FIELDS_STRUCTURE.INPUTFULLSIZE%TYPE,
                  iFIELDORDER FIELDS_STRUCTURE.FIELDORDER%TYPE,
                  iSHOWTYPE FIELDS_STRUCTURE.SHOWTYPE%TYPE,
                  iREQUIRED FIELDS_STRUCTURE.REQUIRED%TYPE,
                  iRELATION_ALL FIELDS_STRUCTURE.RELATION_ALL%TYPE,
                  iHISTORY FIELDS_STRUCTURE.HISTORY%TYPE) 
      RETURN CLOB; 
   FUNCTION UPDATE_ (iID FIELDS_STRUCTURE.ID%TYPE,
                     --iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                     iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                     iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                     iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                     iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                     iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                     iFIELDTYPE FIELDS_STRUCTURE.FIELDTYPE%TYPE,
                     iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                     iRELATION_FIELD FIELDS_STRUCTURE.RELATION_FIELD%TYPE,
                     iTITLE FIELDS_STRUCTURE.TITLE%TYPE,
                     iFIELDSIZE FIELDS_STRUCTURE.FIELDSIZE%TYPE,
                     iINPUTFULLSIZE FIELDS_STRUCTURE.INPUTFULLSIZE%TYPE,
                     iFIELDORDER FIELDS_STRUCTURE.FIELDORDER%TYPE,
                     iSHOWTYPE FIELDS_STRUCTURE.SHOWTYPE%TYPE,
                     iREQUIRED FIELDS_STRUCTURE.REQUIRED%TYPE,
                     iRELATION_ALL FIELDS_STRUCTURE.RELATION_ALL%TYPE,
                     iHISTORY FIELDS_STRUCTURE.HISTORY%TYPE) 
      RETURN CLOB; 
   FUNCTION delete_by_id (iID FIELDS_STRUCTURE.ID%TYPE) RETURN CLOB;
   FUNCTION delete_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN CLOB;
   FUNCTION get_ID  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN FIELDS_STRUCTURE.ID%TYPE;
   FUNCTION get_Structure  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE) RETURN CLOB;
   FUNCTION Select_ (iInput CLOB) RETURN CLOB;   
END p_FIELDS_STRUCTURE;
/

create PACKAGE BODY p_FIELDS_STRUCTURE AS 
   FUNCTION add_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                  iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                  iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                  iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                  iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                  iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                  iFIELDTYPE FIELDS_STRUCTURE.FIELDTYPE%TYPE,
                  iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                  iRELATION_FIELD FIELDS_STRUCTURE.RELATION_FIELD%TYPE,
                  iTITLE FIELDS_STRUCTURE.TITLE%TYPE,
                  iFIELDSIZE FIELDS_STRUCTURE.FIELDSIZE%TYPE,
                  iINPUTFULLSIZE FIELDS_STRUCTURE.INPUTFULLSIZE%TYPE,
                  iFIELDORDER FIELDS_STRUCTURE.FIELDORDER%TYPE,
                  iSHOWTYPE FIELDS_STRUCTURE.SHOWTYPE%TYPE,
                  iREQUIRED FIELDS_STRUCTURE.REQUIRED%TYPE,
                  iRELATION_ALL FIELDS_STRUCTURE.RELATION_ALL%TYPE) 
      RETURN CLOB is
        vID FIELDS_STRUCTURE.ID%TYPE;
        v_return clob;
        v_temp   clob;
          Begin
           insert into FIELDS_STRUCTURE ( TABLE_NAME,  FIELD_NAME,  DATA_TYPE, 
                                          INPUTTYPE,  ISUNIQUE,  USEFORFILTER,
                                          FIELDTYPE,  FROMDICTIONARY,  RELATION_FIELD,  TITLE,  FIELDSIZE,  
                                          INPUTFULLSIZE,  FIELDORDER,  SHOWTYPE, REQUIRED,  RELATION_ALL) 
                                 values (UPPER(iTABLE_NAME), UPPER(iFIELD_NAME), UPPER(iDATA_TYPE), 
                                         iINPUTTYPE, iISUNIQUE, iUSEFORFILTER,
                                         UPPER(iFIELDTYPE), iFROMDICTIONARY, iRELATION_FIELD, iTITLE, iFIELDSIZE, 
                                         iINPUTFULLSIZE, iFIELDORDER, iSHOWTYPE, iREQUIRED, iRELATION_ALL)
                                 returning ID into vID;

           EXECUTE IMMEDIATE 'ALTER TABLE '||iTABLE_NAME||' ADD '||iFIELD_NAME||' '||iDATA_TYPE;
           commit;  
           return Select_('<ROW><WHERE> Where ID = '||vID||' </WHERE></ROW>');
           EXCEPTION
               WHEN OTHERS THEN
                rollback;
                v_return := f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
                if vID is not null then v_temp := delete_by_id(vID); end if; 
              return v_return;
          End;

     
   FUNCTION UPDATE_ (iID FIELDS_STRUCTURE.ID%TYPE,
                     --iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE,
                     iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE,
                     iDATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE,
                     iINPUTTYPE  FIELDS_STRUCTURE.INPUTTYPE%TYPE,
                     iISUNIQUE   FIELDS_STRUCTURE.ISUNIQUE%TYPE,
                     iUSEFORFILTER FIELDS_STRUCTURE.USEFORFILTER%TYPE,
                     iFIELDTYPE FIELDS_STRUCTURE.FIELDTYPE%TYPE,
                     iFROMDICTIONARY FIELDS_STRUCTURE.FROMDICTIONARY%TYPE,
                     iRELATION_FIELD FIELDS_STRUCTURE.RELATION_FIELD%TYPE,
                     iTITLE FIELDS_STRUCTURE.TITLE%TYPE,
                     iFIELDSIZE FIELDS_STRUCTURE.FIELDSIZE%TYPE,
                     iINPUTFULLSIZE FIELDS_STRUCTURE.INPUTFULLSIZE%TYPE,
                     iFIELDORDER FIELDS_STRUCTURE.FIELDORDER%TYPE,
                     iSHOWTYPE FIELDS_STRUCTURE.SHOWTYPE%TYPE,
                     iREQUIRED FIELDS_STRUCTURE.REQUIRED%TYPE,
                     iRELATION_ALL FIELDS_STRUCTURE.RELATION_ALL%TYPE) 
      RETURN CLOB IS
         e_update exception;
         v_err_code number;
         v_err_mes varchar2(100);
         v_TABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE;
         v_FIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE;
         v_DATA_TYPE  FIELDS_STRUCTURE.DATA_TYPE%TYPE;
         v_FIELDTYPE  FIELDS_STRUCTURE.FIELDTYPE%TYPE;
         Begin
         select   TABLE_NAME,   FIELDTYPE,   FIELD_NAME,   DATA_TYPE
           into v_TABLE_NAME, v_FIELDTYPE, v_FIELD_NAME, v_DATA_TYPE
           from FIELDS_STRUCTURE
          where id = iID;
          
            update FIELDS_STRUCTURE
            set --TABLE_NAME = iTABLE_NAME,
                FIELD_NAME = UPPER(iFIELD_NAME),
                --DATA_TYPE =  iDATA_TYPE,
                INPUTTYPE =  iINPUTTYPE,
                ISUNIQUE  =  iISUNIQUE,
                USEFORFILTER = iUSEFORFILTER,
                FIELDTYPE =  UPPER(iFIELDTYPE),
                FROMDICTIONARY = iFROMDICTIONARY,
                RELATION_FIELD = iRELATION_FIELD,
                TITLE = iTITLE,
                FIELDSIZE = iFIELDSIZE,
                INPUTFULLSIZE = iINPUTFULLSIZE,
                FIELDORDER = iFIELDORDER,
                SHOWTYPE = iSHOWTYPE,
                REQUIRED = iREQUIRED,
                RELATION_ALL = iRELATION_ALL
            where id = iID;
            
          if v_DATA_TYPE != UPPER(iDATA_TYPE) 
            then v_err_code := -20001;
                 v_err_mes :=  'DATA_TYPE cannot be modified! Use drop and add function.';
                 raise e_update;
          elsif v_FIELDTYPE in ('SYSTEM','FIXED') and v_FIELDTYPE != UPPER(iFIELDTYPE)
            then v_err_code := -20001;
                 v_err_mes :=  'FIELDTYPE field cannot be SYSTEM or FIXED!';
                 raise e_update; 
          elsif v_FIELD_NAME != UPPER(iFIELD_NAME)  then
            rollback;/* avto commit for alter table*/
            EXECUTE IMMEDIATE 'ALTER TABLE '||v_TABLE_NAME||' RENAME COLUMN '||v_FIELD_NAME||' TO '||iFIELD_NAME;
            update FIELDS_STRUCTURE
            set --TABLE_NAME = iTABLE_NAME,
                FIELD_NAME = UPPER(iFIELD_NAME),
                --DATA_TYPE =  iDATA_TYPE,
                INPUTTYPE =  iINPUTTYPE,
                ISUNIQUE  =  iISUNIQUE,
                USEFORFILTER = iUSEFORFILTER,
                FIELDTYPE =  UPPER(iFIELDTYPE),
                FROMDICTIONARY = iFROMDICTIONARY,
                RELATION_FIELD = iRELATION_FIELD,
                TITLE = iTITLE,
                FIELDSIZE = iFIELDSIZE,
                INPUTFULLSIZE = iINPUTFULLSIZE,
                FIELDORDER = iFIELDORDER,
                SHOWTYPE = iSHOWTYPE,
                REQUIRED = iREQUIRED,
                RELATION_ALL = iRELATION_ALL
            where id = iID;
          end if;
          
           commit;  
           return Select_('<ROW><WHERE> Where ID = '||iID||' </WHERE></ROW>');
           EXCEPTION 
               WHEN e_update THEN
               rollback;
              return f_result_xml(null, v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));            
         End; 

   FUNCTION delete_by_id (iID FIELDS_STRUCTURE.ID%TYPE) RETURN CLOB IS
         e_delete exception;
         v_cnt number;
         v_TABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE;
         v_FIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE;
         v_FIELDTYPE  FIELDS_STRUCTURE.FIELDTYPE%TYPE;
         v_err_code number;
         v_err_mes varchar2(100);
      Begin
         select   TABLE_NAME,   FIELD_NAME, UPPER(FIELDTYPE)
           into v_TABLE_NAME, v_FIELD_NAME,     v_FIELDTYPE
           from FIELDS_STRUCTURE
          where id = iID;
        EXECUTE IMMEDIATE 'select count( '||v_FIELD_NAME||' ) from '||v_TABLE_NAME  into v_cnt;
        if     v_FIELDTYPE in ('SYSTEM','FIXED') then 
           v_err_code := -20001;
           v_err_mes :=  'FIELDTYPE field cannot be SYSTEM or FIXED!';           
           raise e_delete;        
        elsif  v_cnt != 0 then
           v_err_code := -20001;
           v_err_mes :=  v_FIELD_NAME||' field into '||v_TABLE_NAME||' table have '||to_char(v_cnt)||' not null rows.';           
           raise e_delete;
        end if;
        
        EXECUTE IMMEDIATE 'ALTER TABLE '||v_TABLE_NAME||' drop column '||v_FIELD_NAME;
          delete 
          from FIELDS_STRUCTURE
          where id = iID;
          
           commit;  
           return f_result_xml(iID, null, null);
           EXCEPTION 
               WHEN e_delete THEN
              return f_result_xml(null, v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));         
      End;

   FUNCTION delete_ (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN CLOB IS
      v_id FIELDS_STRUCTURE.ID%TYPE;
      Begin
       v_id := get_ID(iTABLE_NAME, iFIELD_NAME);
       return delete_by_id(v_id);
      End;

   FUNCTION get_ID (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE, iFIELD_NAME FIELDS_STRUCTURE.FIELD_NAME%TYPE) RETURN FIELDS_STRUCTURE.ID%TYPE IS
      v_id FIELDS_STRUCTURE.ID%TYPE := -1;
      Begin
       select id 
         into v_id
         from FIELDS_STRUCTURE
        where TABLE_NAME = iTABLE_NAME and FIELD_NAME = iFIELD_NAME;
       return v_id;
      EXCEPTION 
          WHEN OTHERS THEN
          return v_id;                
      End;
   FUNCTION get_Structure  (iTABLE_NAME FIELDS_STRUCTURE.TABLE_NAME%TYPE) 
      RETURN CLOB IS
      v_result CLOB;      
      v_where varchar(4000) := ' where (1=1) ';
      v_ctx  dbms_xmlgen.ctxHandle;
     Begin
      if iTABLE_NAME is not null then v_where := v_where || ' and TABLE_NAME = '''||iTABLE_NAME||''' ';
      end if;
      
--      EXECUTE IMMEDIATE 'select xmlelement("result",  xmlagg(XMLelement("Row",xmlattributes(UPPER(Table_name) as "Table_name"), xmlforest(UPPER(Field_Name) "Field_Name", UPPER(Data_Type) "Data_type"))))
--                        from FIELDS_STRUCTURE '||v_where into v_result;
          v_ctx := dbms_xmlgen.newContext('select TABLE_NAME, FIELD_NAME, DATA_TYPE, FIELDORDER
                                       from FIELDS_STRUCTURE '||v_Where ||' order by FIELDORDER ');
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);
      return v_result;
      EXCEPTION
           WHEN OTHERS THEN
                   dbms_xmlgen.closeContext(v_ctx);
            return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));      
     End; 
   FUNCTION Select_ (iInput CLOB) 
      RETURN CLOB IS
      v_Where varchar(32000);
      v_Order varchar(32000);
      v_result CLOB;
      v_ctx    dbms_xmlgen.ctxHandle;
     Begin
               select extractValue(value(t),'ROW/WHERE[position()=1]') Value_str,
                      extractValue(value(t),'ROW/ORDER[position()=1]') 
               into v_Where, 
                    v_Order
               from table(XMLSequence(XMLType(iInput).extract('//ROW'))) t;
        
          v_ctx := dbms_xmlgen.newContext('select * from FIELDS_STRUCTURE '||v_Where||' '||v_Order );
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);      
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
                   dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
     End; 
END p_FIELDS_STRUCTURE;
/

