create PACKAGE P_DICTIONARYS AS 
   FUNCTION add_ (iCODE DICTIONARYS.CODE%TYPE,
                  iName DICTIONARYS.NAME%TYPE,
                  iParentID  DICTIONARYS.ParentID%TYPE,
                  iText  DICTIONARYS.Text%TYPE,
                  iURL   DICTIONARYS.URL%TYPE,
                  iINFO   DICTIONARYS.INFO%TYPE) 
      RETURN CLOB;
   FUNCTION Select_ (iID        DICTIONARYS.ID%TYPE, 
                     iCODE      DICTIONARYS.CODE%TYPE, 
                     iName      DICTIONARYS.NAME%TYPE, 
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iInput CLOB)
      RETURN CLOB;      
      
   FUNCTION Delete_ (iID DICTIONARYS.ID%TYPE)
      RETURN CLOB;

   Function get_ID  (iCODE DICTIONARYS.CODE%TYPE,
                     iName DICTIONARYS.NAME%TYPE,
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iText  DICTIONARYS.Text%TYPE,
                     iURL   DICTIONARYS.URL%TYPE)
      return DICTIONARYS.ID%TYPE;
      
   FUNCTION Update_ (iID DICTIONARYS.ID%TYPE,
                     iCODE DICTIONARYS.CODE%TYPE,
                     iName DICTIONARYS.NAME%TYPE,
                     iParentID  DICTIONARYS.ParentID%TYPE,
                     iText  DICTIONARYS.Text%TYPE,
                     iURL   DICTIONARYS.URL%TYPE,
                     iINFO   DICTIONARYS.INFO%TYPE)
      RETURN CLOB;
   FUNCTION DictionaryList(iName DICTIONARYS.NAME%TYPE)
      RETURN CLOB;
   FUNCTION Tree_for_ID(iID DICTIONARYS.ID%TYPE)
      RETURN CLOB;
   FUNCTION SelectByList(iList varchar2)
      RETURN CLOB;                           
END P_DICTIONARYS;
/

create PACKAGE BODY P_DICTIONARYS AS 
    FUNCTION add_ (iCODE DICTIONARYS.CODE%TYPE,
                  iName DICTIONARYS.NAME%TYPE,
                  iParentID  DICTIONARYS.ParentID%TYPE,
                  iText  DICTIONARYS.Text%TYPE,
                  iURL   DICTIONARYS.URL%TYPE,
                  iINFO   DICTIONARYS.INFO%TYPE) 
      RETURN CLOB is
      v_ID DICTIONARYS.CODE%TYPE;
     BEGIN
          insert into DICTIONARYS ( CODE,  Name,  ParentID,  Text,  URL,  INFO)
                           values (iCODE, iName, iParentID, iText, iURL, iINFO) returning ID into v_ID;
           commit;

           return Select_(v_ID, null, null, null);
           EXCEPTION
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     END;
      
    FUNCTION Select_ (iID DICTIONARYS.ID%TYPE,
                      iCODE DICTIONARYS.CODE%TYPE, 
                      iName DICTIONARYS.NAME%TYPE, 
                      iParentID  DICTIONARYS.ParentID%TYPE)
      RETURN CLOB IS
      v_result CLOB;
      v_where varchar(4000) := ' where (1=1) ';
      v_ctx    dbms_xmlgen.ctxHandle;      
     Begin
      if iID is not null then v_where := v_where || ' and ID  = '||iID||' ';
      end if;
      if iCode is not null then 
       v_where := v_where || ' and code = '''||iCode||''' ';
      end if;
      if iName is not null then v_where := v_where || ' and Name = '''||iName||''' ';
      end if;
      if iParentID is not null then v_where := v_where || ' and ParentID = '||iParentID||' ';
      end if;
      
--          EXECUTE IMMEDIATE 'select xmlelement("result",  xmlagg(XMLelement("Row", xmlforest(ID as "ID", Code "CODE", Name "NAME", ParentCode "PARENTCODE", Text "TEXT", URL "URL", (select count(d2.id) from DICTIONARYS d2 where d2.PARENTCODE = d.code) "COUNTCHILD"))))
 --from DICTIONARYS d '||v_where into v_result;
--dbms_output.put_line
        v_ctx :=   dbms_xmlgen.newContext('select ID, Code, Name, ParentID, Text, URL, INFO, (select count(d2.id) from DICTIONARYS d2 where d2.PARENTID = d.ID) COUNTCHILD
 from DICTIONARYS d '||v_Where );
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx); 
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               DBMS_XMLGEN.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;
    
    FUNCTION Delete_ (iID DICTIONARYS.ID%TYPE)
      RETURN CLOB is
      v_cnt number;
      v_ID number;
      v_err_code NUMBER;
      v_err_mes varchar(100);
      e_delete exception; 
     Begin
            select ID
              into v_ID
              from DICTIONARYS
             where ID = iID;
             
            select count(id)
              into v_cnt
              from DICTIONARYS
             where ParentID = iID
               and ID != iID;

        if v_cnt > 0 then 
          v_err_code := -20001;
          v_err_mes := 'You can not delete '||iID||' ID. The ID have '||to_char(v_cnt)||' childs.';
          raise e_delete;
        end if;
        
            delete
              from DICTIONARYS
             where ID = iID;

           commit;  
           return f_result_xml(iID, null, null);
           EXCEPTION
               WHEN e_delete THEN
              return f_result_xml(null, v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100)); 
     End;
     
    Function get_ID  (iCODE DICTIONARYS.CODE%TYPE,
                      iName DICTIONARYS.NAME%TYPE,
                      iParentID  DICTIONARYS.ParentID%TYPE,
                      iText  DICTIONARYS.Text%TYPE,
                      iURL   DICTIONARYS.URL%TYPE)
      return DICTIONARYS.ID%TYPE is
      v_ID DICTIONARYS.ID%TYPE := -1;
     Begin
       select ID
         into v_ID
         from DICTIONARYS
        where (Code = iCODE or iCODE is null)
          and (Name = iName or iName is null)
          and (ParentID = iParentID or iParentID is null)
          and (Text = iText or iText is null)
          and (URL = iURL or iURL is null);
       return v_ID;
      EXCEPTION 
          WHEN OTHERS THEN
          return v_id;                     
     End;
    
    FUNCTION Update_ (iID DICTIONARYS.ID%TYPE,
                      iCODE DICTIONARYS.CODE%TYPE,
                      iName DICTIONARYS.NAME%TYPE,
                      iParentID  DICTIONARYS.ParentID%TYPE,
                      iText  DICTIONARYS.Text%TYPE,
                      iURL   DICTIONARYS.URL%TYPE,
                      iINFO  DICTIONARYS.INFO%TYPE)
     RETURN CLOB is
      v_err_code NUMBER;
      v_err_mes varchar(100);
      e_update exception;
      --v_cnt number;
     Begin
       /*select count(id)
         into v_cnt
         from DICTIONARYS
        where ParentID = iID 
          and ID != iID;
          
        if v_cnt > 0 then 
          v_err_code := -20001;
          v_err_mes := 'You can not update '||iID||' ID. The ID have '||to_char(v_cnt)||' childs.';
          raise e_update;
        end if; */

      
      update DICTIONARYS
         set  CODE = iCODE,  
              Name = iName,
              ParentID = iParentID,
              Text = iText,
              URL = iURL,
              INFO = iINFO
       where ID = iID;

           commit;  
           return Select_(iID, null, null, null);
           EXCEPTION
               WHEN e_update THEN
              return f_result_xml(null, v_err_code, v_err_mes);
               WHEN OTHERS THEN
                rollback;
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));         
     End;
     
    FUNCTION DictionaryList(iName DICTIONARYS.NAME%TYPE)
      RETURN CLOB is
      v_result CLOB;
      v_start varchar2(4000) := ' start with ';
      v_level varchar2(100);
      v_ctx    dbms_xmlgen.ctxHandle;
     Begin
      if iName is null then v_start := v_start||' ParentID = 0 ';
                       else v_start := v_start||' Name like '''||iName||''' '; 
      end if;
--      if ilevel is not null and ilevel > 0 then
--       v_level := ' Where level = '||ilevel||' ';
--      end if; 
      
       v_ctx := dbms_xmlgen.newcontextFromHierarchy('select level, xmlelement("ROW", xmlelement("NAME", Name_t)) '||
                                        ' from (select Distinct Name Name_t, prior name PriorName '||
                                                ' from DICTIONARYS '||
--       where CONNECT_BY_ISLEAF = 1
                                                 v_start || 
                                               ' connect by nocycle prior ID = ParentID) t '||
--                                        v_level||
                                        ' start with PriorName is null '||
                                        ' connect by nocycle prior Name_t = PriorName ');
                    dbms_xmlgen.setRowSetTag(v_ctx, 'ROWSET');                           
       /*v_ctx := dbms_xmlgen.newContext('select distinct SYS_CONNECT_BY_PATH(XMLELEMENT(NAME,NAME),''<BRANCH>'')||rpad(''</BRANCH>'',level*9,''</BRANCH>'') TREE
from DICTIONARYS
where CONNECT_BY_ISLEAF = 1 '
||v_start||
' connect by nocycle prior ID = ParentID');*/
                   
                   dbms_xmlgen.SETCONVERTSPECIALCHARS(v_ctx, FALSE);
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2);        
       v_result := dbms_xmlgen.getxml(v_ctx);
       dbms_xmlgen.closeContext(v_ctx);  
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               DBMS_XMLGEN.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));      
     End; 
   FUNCTION Tree_for_ID(iID DICTIONARYS.ID%TYPE)
      RETURN CLOB is
      v_result CLOB;
      v_start varchar2(4000) := ' start with ';
      v_ctx    dbms_xmlgen.ctxHandle;      
     Begin
      if iID is null then v_start := v_start||' ParentID = 0 ';
                     else v_start := v_start||' ID = '||iID||' '; 
      end if;
      
           v_ctx := dbms_xmlgen.newcontextFromHierarchy(
      'select level, xmlelement("ROW", xmlelement("ID", ID), '
                 ||' xmlelement("CODE", code), '
                 ||' xmlelement("NAME", name), '
                 ||' xmlelement("PARENTID", ParentID), '
                 ||' xmlelement("TEXT", text), '
                 ||' xmlelement("URL", url), '
                 ||' xmlelement("INFO", INFO)) from DICTIONARYS '
                 ||v_start 
                 ||' connect by prior ID=ParentID '
                 ||' order siblings by ID');
      
                   dbms_xmlgen.setRowSetTag(v_ctx, 'ROWSET');
                   dbms_xmlgen.SETCONVERTSPECIALCHARS(v_ctx, FALSE);
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2);        
       v_result := dbms_xmlgen.getxml(v_ctx);
       dbms_xmlgen.closeContext(v_ctx);       
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
               DBMS_XMLGEN.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));     
     End;
   FUNCTION SelectByList(iList varchar2)
      RETURN CLOB is
      v_result CLOB;
      v_ctx    dbms_xmlgen.ctxHandle;
     Begin
      
          v_ctx := dbms_xmlgen.newContext('select * from DICTIONARYS Where ID in ( '||iList||' ) ' );
                   dbms_xmlgen.SETNULLHANDLING(v_ctx,2); 
       v_result := dbms_xmlgen.getxml(v_ctx);
                   dbms_xmlgen.closeContext(v_ctx);      
     return v_result;
           EXCEPTION
               WHEN OTHERS THEN
                   dbms_xmlgen.closeContext(v_ctx);
              return f_result_xml(null, SQLCODE, SUBSTR(SQLERRM, 1 , 100));
    End;                                       
END P_DICTIONARYS;
/

