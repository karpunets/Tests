create function f_result_xml (iID number, iCode number, iMessage varchar)
 return CLOB is
 v_result CLOB;
 v_ctx    dbms_xmlgen.ctxHandle;
 vID varchar2(10) := 'null';
 vCode varchar2(10) := 'null';
 Begin
 if iID is not null then vID := to_char(iID); end if;
 if iCode is not null then vCode := to_char(iCode); end if; 
  v_ctx := dbms_xmlgen.newContext('select '||vID||' ID, '||vCode||' Err_Code, '''||replace(iMessage,'''','''''')||''' Err_Name from dual');
   --dbms_xmlgen.setRowSetTag(ctx, 'result');
  --dbms_xmlgen.setRowTag(ctx, 'Row');
  v_result := dbms_xmlgen.getxml(v_ctx);
  --dbms_output.put_line(xml_out.getstringval());
 
  dbms_xmlgen.closeContext(v_ctx);
  return v_result;
 End;
/

