create PACKAGE P_Rep AS
   FUNCTION put_ (iID       Rep.ID%TYPE,
                  iNAME     Rep.NAME%TYPE,
                  iTITLE    Rep.TITLE%TYPE, 
                  iTABLE_1  Rep.TABLE_1%TYPE,
                  iJOIN_CL  Rep.JOIN_CL%TYPE,
                  iTABLE_N  Rep.TABLE_N%TYPE,
                  iON_CL    Rep.ON_CL%TYPE,
                  iFIELDS   Rep.FIELDS%TYPE,
                  iWHERE_CL Rep.WHERE_CL%TYPE,
                  iORDER_CL Rep.ORDER_CL%TYPE,
                  iGROUP_CL Rep.GROUP_CL%TYPE,
                  iREPTYPE  Rep.REPTYPE%TYPE,
                  iPosition Rep.Position%TYPE)
    
      RETURN CLOB;
   FUNCTION Select_ (iInput CLOB, iSkipRows number, iMaxRows number)
      RETURN CLOB;      
   FUNCTION Delete_ (iID Rep.ID%TYPE)
      RETURN CLOB;
   FUNCTION Execute_ (iNAME Rep.Name%TYPE, iInput CLOB, iSkipRows number, iMaxRows number)
      RETURN CLOB;      
   FUNCTION Count_Ex  (iNAME Rep.Name%TYPE, iInput CLOB)
      RETURN CLOB;   
END P_Rep;
/

