create FUNCTION f_get_Fields(iTable_Name FIELDS_STRUCTURE.TABLE_NAME%TYPE)
  RETURN SYS_REFCURSOR
AS
  v_my_cursor SYS_REFCURSOR;
BEGIN
  OPEN v_my_cursor FOR SELECT tab.Field_Name, tab.Data_type
                          FROM XMLTable('//ROWSET/ROW' passing XMLType(p_FIELDS_STRUCTURE.get_Structure(iTable_Name))
                            columns Field_Name varchar2(4000) path 'FIELD_NAME',
                                    Data_type  varchar2(4000) path 'DATA_TYPE',
                                    FIELDORDER number path 'FIELDORDER') tab
                        order by tab.FIELDORDER;
  RETURN v_my_cursor;
END f_get_Fields;
/

